# Grocery-Store-Management-System-SJ
This is simple python project for demo purpose with simple GUI and few Features
